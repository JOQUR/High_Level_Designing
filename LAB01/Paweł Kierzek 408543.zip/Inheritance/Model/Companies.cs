﻿namespace Inheritance.Model
{
    public enum Companies
    {
        notSpecified,
        Ford,
        Skoda,
        Seat,
        Ferrari
    }
}
