﻿namespace Polymorphism
{
    public enum PersonalComputers
    {
        Laptop = 20,
        Station = 120,
        Console = 75
    }
}