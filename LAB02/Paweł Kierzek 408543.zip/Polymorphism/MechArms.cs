﻿namespace Polymorphism
{
    public enum MechArms
    {
        Crane = 1,
        Transformer = 20,
        AssemblyArm = 10
    }
}