﻿namespace C3
{
    public class FuelNuclear : Fuel 
    {
        public FuelNuclear()
        {
            Material = "nuclear";
            density = 1;
        }
    }
}
