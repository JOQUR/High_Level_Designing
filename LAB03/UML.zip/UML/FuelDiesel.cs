﻿namespace C3
{
    public class FuelDiesel : Fuel
    {
        public FuelDiesel()
        {
            Material = "diesel";
            density = 0.5;
        }
    }
}
